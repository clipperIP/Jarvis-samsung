# JARVIS Android Starter

This is a fresh native Android starter project for a personal voice assistant.

## Included in this starter
- Native Android app interface
- Speech-to-text using Android's available recognizer (tap TALK)
- Spoken replies using Android TextToSpeech
- Local saved memory and locally persisted chat transcript
- Optional OpenAI-compatible chat connection (starter currently targets OpenAI's chat completions API)
- GitHub Actions workflow to build a debug APK

## Important limitations
This is a starter foundation, not a finished fully autonomous assistant. It does **not** yet send Gmail messages, send SMS, operate other apps, use Fish Audio, or provide an always-on wake word. Those need separate integrations, OAuth/permissions, service credentials, and device testing. Gmail should be integrated with Google OAuth; never ask users to paste their Gmail password into this app.

For a safer production setup, proxy AI requests through a backend so a provider API key is not shipped in an APK. The included direct-key option is for development/testing only.

## Build the APK from your phone with GitHub
1. Create a new GitHub repository named `jarvis-android`.
2. Upload the contents of this folder (not the ZIP itself) to the repository root.
3. Open the repository's **Actions** tab and select **Build JARVIS APK**.
4. Tap **Run workflow** if it has not started automatically.
5. When it succeeds, open the run, scroll to **Artifacts**, and download `JARVIS-debug-APK`.
6. Extract the downloaded artifact and install `app-debug.apk` on your Android phone. Android may ask you to allow installs from your browser or file manager.

## Minimum requirements
- Android 8.0 (API 26) or later
- Internet is required for the optional online AI service
- Speech recognition availability depends on device services and language settings

## Next development stages
1. Secure backend and provider configuration
2. Gmail OAuth and read/draft/send workflow with explicit approval
3. Contacts lookup and SMS integration with runtime permissions
4. Fish Audio voice integration
5. Foreground service and carefully designed wake-word support
6. Offline model integration if device storage, memory, and performance allow
