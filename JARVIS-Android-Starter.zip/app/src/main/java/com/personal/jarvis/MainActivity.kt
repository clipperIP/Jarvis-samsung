package com.personal.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private val prefs by lazy { getSharedPreferences("jarvis_memory", MODE_PRIVATE) }
    private val SPEECH_REQUEST = 101
    private val MIC_PERMISSION = 102
    private val API_KEY_PREF = "api_key"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        transcript.text = prefs.getString("history", "JARVIS initialized.\nYour conversations can be saved locally on this device.\n")
        status.text = "SYSTEM ONLINE • LOCAL MEMORY READY"
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 42, 28, 24)
            setBackgroundColor(0xFF07111F.toInt())
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(0xFF66E6FF.toInt())
        }
        status = TextView(this).apply {
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(0xFF9CB9C8.toInt())
            setPadding(0, 8, 0, 18)
        }
        transcript = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFFEAF6FF.toInt())
            setPadding(14, 14, 14, 14)
        }
        val scroll = ScrollView(this).apply { addView(transcript) }
        input = EditText(this).apply {
            hint = "Ask JARVIS something…"
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9CB9C8.toInt())
        }
        val send = Button(this).apply {
            text = "SEND"
            setOnClickListener { submit(input.text.toString()) }
        }
        val mic = Button(this).apply {
            text = "TALK"
            setOnClickListener { startListening() }
        }
        val memory = Button(this).apply {
            text = "SAVE AS MEMORY"
            setOnClickListener {
                val value = input.text.toString().trim()
                if (value.isNotEmpty()) {
                    val old = prefs.getString("memories", "") ?: ""
                    prefs.edit().putString("memories", (old + "\n• " + value).takeLast(12000)).apply()
                    append("JARVIS", "Saved to local memory.")
                    input.text.clear()
                } else Toast.makeText(this@MainActivity, "Type a fact to save first.", Toast.LENGTH_SHORT).show()
            }
        }
        val keyButton = Button(this).apply {
            text = "SET AI API KEY"
            setOnClickListener { promptForKey() }
        }
        outer.addView(title)
        outer.addView(status)
        outer.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        outer.addView(input)
        outer.addView(send)
        outer.addView(mic)
        outer.addView(memory)
        outer.addView(keyButton)
        setContentView(outer)
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) tts.language = Locale.US
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), MIC_PERMISSION)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        try { startActivityForResult(intent, SPEECH_REQUEST) }
        catch (_: Exception) { Toast.makeText(this, "Speech recognition is not available on this device.", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Legacy activity result API retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == SPEECH_REQUEST && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            input.setText(spoken)
            submit(spoken)
        }
    }

    private fun submit(text: String) {
        val request = text.trim()
        if (request.isEmpty()) return
        append("YOU", request)
        input.text.clear()
        val key = prefs.getString(API_KEY_PREF, "") ?: ""
        if (key.isBlank()) {
            val reply = localReply(request)
            append("JARVIS", reply)
            speak(reply)
            return
        }
        status.text = "CONTACTING AI SERVICE…"
        thread {
            val reply = try { callOpenAiCompatibleApi(key, request) }
            catch (e: Exception) { "I couldn't reach the AI service. Check your internet and API settings. (${e.javaClass.simpleName})" }
            runOnUiThread {
                status.text = "SYSTEM ONLINE • LOCAL MEMORY READY"
                append("JARVIS", reply)
                speak(reply)
            }
        }
    }

    private fun localReply(request: String): String {
        val memories = prefs.getString("memories", "").orEmpty()
        val q = request.lowercase(Locale.ROOT)
        return when {
            q.contains("memory") || q.contains("remember") ->
                if (memories.isBlank()) "I don't have any saved facts yet. You can type a fact and tap Save As Memory." else "Here is what I have saved locally:$memories"
            q.contains("hello") || q.contains("hi jarvis") -> "Hello. JARVIS is online locally. Add an AI API key for advanced conversation."
            else -> "I am running in local starter mode. For advanced AI, tap Set AI API Key and enter a compatible service key. Local memory and speech output remain available without that connection."
        }
    }

    private fun callOpenAiCompatibleApi(key: String, prompt: String): String {
        val conn = (URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection)
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.setRequestProperty("Authorization", "Bearer $key")
        conn.setRequestProperty("Content-Type", "application/json")
        conn.doOutput = true
        val memory = prefs.getString("memories", "").orEmpty()
        val body = JSONObject().apply {
            put("model", "gpt-4o-mini")
            put("messages", org.json.JSONArray().apply {
                put(JSONObject().put("role", "system").put("content", "You are JARVIS, a helpful personal phone assistant. Saved user memory: $memory. Do not claim to have performed actions on the phone unless an integration actually did so."))
                put(JSONObject().put("role", "user").put("content", prompt))
            })
        }.toString()
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        if (conn.responseCode !in 200..299) throw IllegalStateException("AI service returned HTTP ${conn.responseCode}")
        return JSONObject(response).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }

    private fun promptForKey() {
        val field = EditText(this).apply {
            hint = "API key (stored on this device)"
            inputType = 129
            setText(prefs.getString(API_KEY_PREF, ""))
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("AI connection")
            .setMessage("Starter build connects to OpenAI-compatible chat completions. For a production app, keep provider keys on a secure backend instead of embedding them in an APK.")
            .setView(field)
            .setPositiveButton("Save") { _, _ -> prefs.edit().putString(API_KEY_PREF, field.text.toString().trim()).apply(); Toast.makeText(this, "Key saved on this device.", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun append(who: String, message: String) {
        val line = "\n$who: $message\n"
        transcript.append(line)
        val old = prefs.getString("history", "") ?: ""
        prefs.edit().putString("history", (old + line).takeLast(16000)).apply()
    }

    private fun speak(text: String) { if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-reply") }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
